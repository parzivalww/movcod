// JavaScript Principal
console.log('🚀 sf carregado!');

// Adicione seu código aqui
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM pronto!');
});